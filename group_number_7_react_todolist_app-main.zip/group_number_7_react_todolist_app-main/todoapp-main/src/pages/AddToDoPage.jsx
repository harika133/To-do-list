import React from 'react'
import AddTodo from '../components/AddTodo'

const AddToDoPage = () => {
  return (
    <div>
      <AddTodo/>
    </div>
  )
}

export default AddToDoPage
